"""
 Sort all possibilities
"""

# Merge sort implementation
def merge_sort(lst):
    # Merge Sort a list of numbers or strings.

    # In: lst -- A list of numbers or strings to be sorted.
    # Out: A sorted list.

    # Dividing the list into the smallest possible lists:
    if len(lst) <= 1:
        return lst
    else: # We do the division here:
        mid = len(lst) // 2
        left_side = merge_sort(lst[:mid]) # Divide the left side even more since it's still big
        right_side = merge_sort(lst[mid:]) # Divide the right side even more since it's still big
        return merge(left_side, right_side) # Sort the divided lists


def merge(left_side, right_side):
    # Merge two sorted lists into one sorted list.

    # in:
    # left_side -- A sorted list of numbers or strings.
    # right_side -- A sorted list of numbers or strings.

    # out: A sorted list.

    results = []  # New list for sorted List


    # Go over the new lists and fill up the results list by comparison of first cells (lowest cells):
    while len(left_side) != 0 and len(right_side) != 0:

        # Check if the first element of both lists are strings
        if isinstance(left_side[0], str) and isinstance(right_side[0], str):
            # If both elements are strings, perform a case-insensitive comparison
            if left_side[0].lower() <= right_side[0].lower():
                results.append(left_side[0])
                left_side.pop(0)
            else:
                results.append(right_side[0])
                right_side.pop(0)
        else:
            # If the first element of both lists are not strings, perform a normal comparison
            if left_side[0] <= right_side[0]:
                results.append(left_side[0])
                left_side.pop(0)
            else:
                results.append(right_side[0])
                right_side.pop(0)

    # Fill the rest of what's left to the results list
    results += left_side
    results += right_side

    # Return the sorted list
    return results



"""
 Sort nummerical
"""


def MergeSortNummerical(list):
    # dividing the list into the smallest possible lists:
    if len(list) <= 1:
        return list
    else: # we do the division here:
        mid = len(list) // 2
        leftSide = MergeSortNummerical(list[:mid]) # Divide the left side even more since it's still big
        rightSide = MergeSortNummerical(list[mid:]) # Divide the right side even more since it's still bigs
        return forMergeNummerical(leftSide, rightSide) # Sort the divided lists

def forMergeNummerical(leftSide, rightSide):
    results = [] # New list for sorted List

    # Go over the new lists and fill up the results list by comparison of first cells (lowest cells):
    while len(leftSide) != 0 and len(rightSide) != 0:

        if (leftSide[0] < rightSide[0]):
            results.append(leftSide[0])
            leftSide.pop(0)
        else:
            results.append(rightSide[0])
            rightSide.pop(0)
    
    # Fill the rest of whats left to the results list
    while len(leftSide) > 0:
        results.append(leftSide.pop(0))
    while len(rightSide) > 0:
        results.append(rightSide.pop(0))
    
    # Return the sorted list
    return results

"""
 Sort alphabetical
"""

# Merge sort for strings by alphabetical

def MergeSortABC(list):
        # dividing the list into the smallest possible lists:
    if len(list) <= 1:
        return list
    else: # we do the division here:
        mid = len(list) // 2
        leftSide = MergeSortABC(list[:mid]) # Divide the left side even more since it's still big
        rightSide = MergeSortABC(list[mid:]) # Divide the right side even more since it's still bigs
        return forMergeABC(leftSide, rightSide) # Sort the divided lists

def forMergeABC(leftSide, rightSide):
    results = [] # New list for sorted List

    # Go over the new lists and fill up the results list by comparison of first cells (lowest cells):
    while len(leftSide) != 0 and len(rightSide) != 0:

        # Just quickly checking if in case it is not a number :)
        if type(leftSide[0]) is str:
            tempLeft = leftSide[0][0].upper() # leftSide = word array || leftSide[0] = word || leftSide[0][0] = First Letter
            tempRight = rightSide[0][0].upper()
        
        if (tempLeft < tempRight):
            results.append(leftSide[0])
            leftSide.pop(0)
        else:
            results.append(rightSide[0])
            rightSide.pop(0)
    
    # Fill the rest of whats left to the results list
    while len(leftSide) > 0:
        results.append(leftSide.pop(0))
    while len(rightSide) > 0:
        results.append(rightSide.pop(0))
    
    # Return the sorted list
    return results

print(merge_sort(["hey", "Now", "Your", "An", "All Star", "Put", "Your", "Game", "on", "Go", "Play"]))
print(merge_sort(["A", "b", "D", "Y", "Z", "e", "H"]))
print(merge_sort([0, 13, 1, 4, 3, 5, 2]))
print(merge_sort([1, 3, 4, 5, 2]))