
singers = ["Sbarit Dahaha Lmao", "Sarit Hadad","Eyal Golan","Miri Masika", "Nechi Nech","Keren Peles","Roni Dalumi","Yoni Bloch","Eric Berman","Noa Kirel","Jonathan Mergi","Roni Duani","Jonathan Rezal","Ishay Ribo"]
player_score=[11,3,12,21,2,4,2]
player_fouls=[0,1,3,2,1,4,4]
Dictionary=[["ability","about","acknowledge","actor","airplane","avocado"],
            ["cake","candy","cash","cat"],
            ["category", "champion", "early", "earth"]]

def hillRunner():
    # EX1:
    global singers
    singers = mergeSortNames(singers)
    print(singers)

    # EX2:
    footBallLegacy()

    # EX3:
    print(num_Detector([1, 2, 3, 4, 5, 5, 9]))
    print(num_Detector_Times_Minus1([1, 2, 3, 4, 5, 5, 9]))

    # EX4:
    print(PageSweep("champion"))


# EX1:
def mergeSortNames(list):
        # dividing the list into the smallest possible lists:
    if len(list) <= 1:
        return list
    else: # we do the division here:
        mid = len(list) // 2
        leftSide = mergeSortNames(list[:mid]) # Divide the left side even more since it's still big
        rightSide = mergeSortNames(list[mid:]) # Divide the right side even more since it's still bigs
        return forMergeNames(leftSide, rightSide) # Sort the divided lists

def forMergeNames(leftSide, rightSide):
    results = [] # New list for sorted List

    # Go over the new lists and fill up the results list by comparison of first cells (lowest cells):
    while len(leftSide) != 0 and len(rightSide) != 0:

        # Just quickly checking if in case it is not a number :)
        if type(leftSide[0]) is str:
            tempLeft = leftSide[0][0].upper() # leftSide = word array || leftSide[0] = word || leftSide[0][0] = First Letter
            tempRight = rightSide[0][0].upper()
        
        if (tempLeft == tempRight):
            if leftSide[0][1] < rightSide[0][1]:
                results.append(leftSide[0])
                leftSide.pop(0)
            else:
                results.append(rightSide[0])
                rightSide.pop(0)
        elif (tempLeft < tempRight):
            results.append(leftSide[0])
            leftSide.pop(0)
        else:
            results.append(rightSide[0])
            rightSide.pop(0)
    
    # Fill the rest of whats left to the results list
    while len(leftSide) > 0:
        results.append(leftSide.pop(0))
    while len(rightSide) > 0:
        results.append(rightSide.pop(0))
    
    # Return the sorted list
    return results

# EX2:
def footBallLegacy():
    global player_score
    global player_fouls

    while (action := int(input("Enter a number 1 - 5\n"))) != 5:
        match action:
            case 1:
                print("Adding scores!")
                print("Which player?")
                try:
                    current_Player = int(input())
                except ValueError2:
                    print("Try Numbers.")
                print("How many buskets?")
                current_Baskets = input()

                try:
                    # add score:
                    newScore = current_Baskets.replace(" ", "")
                    if "," not in newScore:
                        player_score[current_Player] += int(newScore)
                    else:
                        newScore = list(newScore.split(","))
                        player_score[current_Player] += sum(newScore)
                except IndexError:
                    print("Player doesn't exist!")
            case 2:
                print("Adding fouls!")
                print("Which player?")
                try:
                    current_Player = int(input())
                except ValueError:
                    print("Try Numbers.")
                print("How many fouls?")
                newFouls = input()

                # add fouls
                try:
                    player_fouls[current_Player] += int(newFouls)
                except ValueError:
                    print("Fouls are counted in numbers dummy...")
            case 3:
                # Linear Search

                max_busket_index = 0
                for i in range(len(player_score)):
                    if (player_score[i] > player_score[max_busket_index]):
                        max_busket_index = i
                
                print("Leading Player is player number " + str(max_busket_index) + " With a leading score of", str(player_score[max_busket_index]) + "!")
            case 4:
                # Also linear Search

                max_fouls_index = 0
                for i in range(len(player_fouls)):
                    if (player_fouls[i] > player_fouls[max_fouls_index]):
                        max_fouls_index = i
                
                print("Worst Player is player number " + str(max_fouls_index) + " With a pretty awful score of", str(player_fouls[max_fouls_index]) + "!")
        
        print("---------------------------------------------------")
        print("And the Score, Is! ", player_score)
        print("And the Fouls, Are! ", player_fouls)
    
    print("Good Night!")

# EX3:
def num_Detector(list):
    try:
        num = int(input("Which number are you looking for? \n"))
    except ValueError:
        print("I said number!!!")
    # Linear Search:

    # The list is 100% num and 100% Orginized.

    for i in range(len(list)):
        if (list[i] == num):
            return i
    raise FileNotFoundError
            
# EX3:
def num_Detector_Times_Minus1(list):
    try:
        num = int(input("Which number are you looking for? \n"))
    except ValueError:
        print("I said number!!!")
    # Linear Search:

    # The list is 100% num and 100% Orginized.

    for i in range(len(list) - 1, 0, -1):
        if (list[i] == num):
            return i
    raise FileNotFoundError

# EX4 ? (did I get it Right?):
def PageSweep(word):
    from YonatanSort import MergeSortABC
    # considering they are ordered by ABC

    global Dictionary

    i = 0
    for list in Dictionary:
        i = 0
        for listItem in list:
            i += 1 # First I add i to index starting with Zero and word requiring one above compensation.
            if word == listItem:
                return list, i
    
    return None


# Answers Checks:

hillRunner()